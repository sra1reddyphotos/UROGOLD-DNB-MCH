import { TOPICS } from "./topics";
import type { Master, TopicId, TopicMeta } from "./types";
import { adrenal } from "./answers/adrenal";
import { basics } from "./answers/basics";
import { bladder } from "./answers/bladder";
import { drugs } from "./answers/drugs";
import { evaluation } from "./answers/evaluation";
import { functional } from "./answers/functional";
import { infections } from "./answers/infections";
import { infertility } from "./answers/infertility";
import { laparoscopy } from "./answers/laparoscopy";
import { lasers } from "./answers/lasers";
import { misc } from "./answers/misc";
import { nephrology } from "./answers/nephrology";
import { paediatric } from "./answers/paediatric";
import { penis } from "./answers/penis";
import { prostate } from "./answers/prostate";
import { recent } from "./answers/recent";
import { renalAnatomy } from "./answers/renal-anatomy";
import { renalSurgery } from "./answers/renal-surgery";
import { renalTrauma } from "./answers/renal-trauma";
import { renalTumors } from "./answers/renal-tumors";
import { sexual } from "./answers/sexual";
import { stats } from "./answers/stats";
import { stones } from "./answers/stones";
import { testes } from "./answers/testes";
import { transplant } from "./answers/transplant";
import { ureter } from "./answers/ureter";
import { urethra } from "./answers/urethra";

export const MASTERS: Master[] = [
  ...basics,
  ...drugs,
  ...evaluation,
  ...lasers,
  ...laparoscopy,
  ...paediatric,
  ...infections,
  ...infertility,
  ...sexual,
  ...testes,
  ...penis,
  ...renalAnatomy,
  ...nephrology,
  ...renalTrauma,
  ...renalTumors,
  ...renalSurgery,
  ...stones,
  ...ureter,
  ...adrenal,
  ...functional,
  ...bladder,
  ...prostate,
  ...urethra,
  ...transplant,
  ...recent,
  ...stats,
  ...misc,
];

export function topicById(id: string): TopicMeta | undefined {
  return TOPICS.find((t) => t.id === id);
}

export function mastersForTopic(id: TopicId): Master[] {
  return MASTERS.filter((m) => m.topicId === id);
}

export function getMaster(id: string): Master | undefined {
  return MASTERS.find((m) => m.id === id);
}

export function examCount(m: Master): number {
  return m.exams.length;
}

export function searchMasters(raw: string): Master[] {
  const q = raw.trim().toLowerCase();
  if (!q) return [];
  const parts = q.split(/\s+/);
  return MASTERS.filter((m) => {
    const hay = [
      m.title,
      m.tags.join(" "),
      m.exams.map((e) => e.stem).join(" "),
      m.topicId,
    ]
      .join(" ")
      .toLowerCase();
    return parts.every((p) => hay.includes(p));
  });
}

export function allYears(): number[] {
  const set = new Set<number>();
  for (const m of MASTERS) for (const e of m.exams) set.add(e.year);
  return [...set].sort((a, b) => b - a);
}

export function mastersByYear(year: number): Master[] {
  return MASTERS.filter((m) => m.exams.some((e) => e.year === year));
}

export const STATS = {
  topics: TOPICS.length,
  masters: MASTERS.length,
  papers: MASTERS.reduce((n, m) => n + m.exams.length, 0),
  highYield: MASTERS.filter((m) => m.highYield).length,
  gold: MASTERS.filter((m) => m.gold).length,
};
