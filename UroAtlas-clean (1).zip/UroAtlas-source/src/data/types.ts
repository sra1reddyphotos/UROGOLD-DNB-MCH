export type Session = "Jun" | "Dec" | "June";

export type ExamHit = {
  session: Session;
  year: number;
  marks: string;
  stem: string;
};

export type FlowNode = {
  id: string;
  label: string;
  note?: string;
  kind?: "start" | "decision" | "action" | "end" | "warn";
  to?: string[];
};

export type Block =
  | { t: "p"; v: string }
  | { t: "h"; v: string; l?: 2 | 3 }
  | { t: "ul"; v: string[]; n?: boolean }
  | { t: "tbl"; h: string[]; r: string[][]; c?: string }
  | { t: "flow"; title?: string; nodes: FlowNode[] }
  | { t: "tip"; k: "gold" | "exam" | "warn" | "book"; title?: string; v: string }
  | { t: "dia"; id: string; cap?: string }
  | { t: "refs"; v: string[] }
  | { t: "kpi"; items: { k: string; v: string }[] };

export type TopicId =
  | "basics"
  | "drugs"
  | "evaluation"
  | "lasers"
  | "laparoscopy"
  | "paediatric"
  | "infections"
  | "infertility"
  | "sexual"
  | "testes"
  | "penis"
  | "renal-anatomy"
  | "nephrology"
  | "renal-trauma"
  | "renal-tumors"
  | "renal-surgery"
  | "stones"
  | "ureter"
  | "adrenal"
  | "functional"
  | "bladder"
  | "prostate"
  | "urethra"
  | "transplant"
  | "recent"
  | "stats"
  | "misc";

export type TopicMeta = {
  id: TopicId;
  title: string;
  short: string;
  blurb: string;
  chapter: string;
};

export type Master = {
  id: string;
  topicId: TopicId;
  title: string;
  highYield: boolean;
  gold: boolean;
  tags: string[];
  exams: ExamHit[];
  answer: Block[];
  references: string[];
  related: string[];
};
